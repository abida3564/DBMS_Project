<?php

	session_start();
	session_destroy();
	window.location = "dashboard.php";


?>